<?php 
function abone_import() { 

if(isset($_POST['but_submit'])){
	
	if($_FILES['file']['name'] != ''){
		
		$yuklenen_dosya = $_FILES['file'];
		
		$yuklenen_dosya_tasima =  wp_handle_upload($yuklenen_dosya, array('test_form' => false, 'mimes' => array('csv' => 'text/csv')));
		
		if($yuklenen_dosya_tasima['type'] != "text/csv"){
				
			echo '<div class="notice notice-error is-dismissible">
				  <p>Yüklediğiniz dosyanın csv formatında olması gerekmektedir.</p>
				  </div>';
		}
		
		else{
			
			$yuklenen_dosya_url = "";
			$yuklenen_dosya_url = $yuklenen_dosya_tasima['url'];
			
			$url = $yuklenen_dosya_url;
			$curl = curl_init();
			curl_setopt($curl, CURLOPT_URL, $url);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curl, CURLOPT_HEADER, false);
			$data = curl_exec($curl);
			$satirlar = str_getcsv($data, "\n");
			
			$sayac = "0";
			
			foreach ($satirlar as $satir) {
				
				$satir = str_getcsv($satir);
				
				if ($sayac == 0) {
						
					
				}
				
				else{
					
					$abone_email_adresi = $satir[0];	
					
					$bulunan_icerik = get_page_by_title( $abone_email_adresi, OBJECT, "ebultenabonesi" );
					$bulunan_icerik_id = $bulunan_icerik->ID;
					
					
					if( $bulunan_icerik ) {
						
						
					}
					
					else {
						
						$post_data = array(
						'post_title'    => $abone_email_adresi ,
						'post_type'     => 'ebultenabonesi',
						'post_status'   => 'publish'
						);
						$post_id = wp_insert_post( $post_data );
						
						update_post_meta($post_id, 'e-posta_adresi', $abone_email_adresi );	
						update_post_meta($post_id, 'onay_durumu', "Hayır" );
						update_post_meta($post_id, 'gonderilenler',array());	
						
					}
					
					
				}
				
				$sayac++;
			}
			
			
			
		}
		
		echo '<div class="notice notice-success is-dismissible">
				  <p>Aktarım tamamlanmıştır.</p>
				  </div>';
				
		curl_close($curl);
		
		
	}
	
}




?>

<div class="wrap">
<h2>Aboneleri İçeri Aktar</h2>
<p>Yükleyeceğiniz csv dosyasından içeri abone aktarabilirsiniz.</p>	
<form method="post" action="" enctype="multipart/form-data">
<input type="file" class="file-url regular-text" name="file">	
<button type="submit" name="but_submit" class="button button-primary">Yükle</button>	
</form>
</div>

<?php
	
	
	
}

add_action('admin_post_nopriv_aboneleri_iceri_aktar_func','aboneleri_iceri_aktar_func');
add_action('admin_post_aboneleri_iceri_aktar_func','aboneleri_iceri_aktar_func');