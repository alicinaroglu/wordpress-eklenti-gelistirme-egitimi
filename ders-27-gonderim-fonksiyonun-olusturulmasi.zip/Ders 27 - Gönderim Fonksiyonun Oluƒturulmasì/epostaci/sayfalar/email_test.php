<?php function email_test(){ 

	
if(isset($_POST['but_submit'])){
	$gonderilecek_email = $_POST['gonderilecek_email'];
	$konu = $_POST['konu'];
	$test_email_gonderimi = wp_mail($gonderilecek_email,$konu,$konu);
	
	if($test_email_gonderimi) {
	   echo '<div class="notice notice-success"><p>E-Postacı - Test E-Posta Gönderildi.</p></div>';
	}
	
}
	

?>

<div class="wrap">
<h2>E-Postacı E-Mail Test Alanı</h2>
<form method="post" action="" enctype="multipart/form-data">
<input type="email" required name="gonderilecek_email" id="gonderilecek_email" placeholder="Gönderilecek e-mail">
<input type="text" name="konu" id="konu" placeholder="Konu">	
<button type="submit" name="but_submit" class="button button-primary">Çalıştır</button>	
</form>
</div>
<?php	
}

add_action( 'email_test', 'email_test' );	