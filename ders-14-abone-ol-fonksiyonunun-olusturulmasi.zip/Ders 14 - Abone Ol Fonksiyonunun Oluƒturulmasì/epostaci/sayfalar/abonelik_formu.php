<?php
function abonelik_formu_shortcode($args,$content=""){ 

session_destroy ();
if(isset($_SESSION['kullanici_uyarilari'])) {
   $uyari = $_SESSION['kullanici_uyarilari'];
} else {
   $uyari = '';
}
	

?>
<?php echo $uyari;?>	
<form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
	
<input type="email" name="email_adresi" id="email_adresi" placeholder="<?php _e( 'E-Mail Adresiniz', 'e-postaci' );?>" value="" required>
	
<img id="captcha" style="display: inline-block;" src="<?php echo plugin_dir_url( __DIR__ );?>/inc/securimage/securimage_show.php" alt="<?php _e( 'Doğrulama Kodu', 'e-postaci' );?>" />
	
<a href="#" onclick="document.getElementById('captcha').src = '<?php echo plugin_dir_url( __DIR__ );?>/inc/securimage/securimage_show.php?' + Math.random(); return false"><?php _e( 'Kodu Yenile', 'e-postaci' );?></a>
	
<input type="text" name="captcha_code" size="10" maxlength="6" placeholder="<?php _e( 'Doğrulama Kodunu Buraya Yazınız', 'e-postaci' );?>" />	
	
<?php wp_nonce_field( 'listeye_abone_ekle', 'listeye_abone_ekle_nonce' ); ?>
<input type="hidden" name="action" value="listeye_abone_ekle">
	
<input type="hidden" name="onay_kodu" value="<?php echo $onay_kodu = md5(time());?>">		
	
<input type="submit" name="" value="<?php _e( 'Abone Ol', 'e-postaci' );?>"/>	
</form>

<?php
}
add_shortcode('abonelik_formu', 'abonelik_formu_shortcode');

function listeye_abone_ekle() {
	
	global $post;
	
	$abone_email_adresi = $_POST['email_adresi'];
	$captcha = $_POST['captcha_code'];
	$onaykodu = $_POST['onay_kodu'];	
	
	$args = array(
	'numberposts'	=> -1,
	'post_type'		=> 'ebultenabonesi',
	'meta_key'		=> 'e-posta_adresi',
	'meta_value'	=> $abone_email_adresi,
	);

	$abone_kontrol = new WP_Query( $args );
	
	include_once( plugin_dir_path( __DIR__ ) . 'inc/securimage/securimage.php');	
	$securimage = new Securimage();
	
	//echo "<pre>"; print_r($abone_kontrol); echo "</pre>";
	
	if ($securimage->check($captcha) == false) {
		
		$_SESSION['kullanici_uyarilari'] .= '<p>Girdiğiniz kod hatalı</p>';	
		
	}
	
	else {
		
		if($abone_kontrol->post_count > 0 ) {
		
			$_SESSION['kullanici_uyarilari'] .= '<p>Bu e-posta adresi ile abonelik mevcut.</p>';	
		
		}
	
		else {
		
			$post_data = array(
			'post_title'    => $abone_email_adresi ,
			'post_type'     => 'ebultenabonesi',
			'post_status'   => 'publish'
			);
			$post_id = wp_insert_post( $post_data );

			update_post_meta( $post_id,'e-posta_adresi', $abone_email_adresi);
			update_post_meta( $post_id,'onay_kodu', $onaykodu);
			update_post_meta( $post_id,'onay_durumu', "Hayır");
			update_post_meta( $post_id,'gonderilenler', array());
			
			$eposta_ayarlar = get_option( 'epostaci_ayarlar_secenekler' );
			
			$eposta_ayarlar_gonderen = $eposta_ayarlar['gonderen_baslik'];
			$eposta_ayarlar_email = $eposta_ayarlar['gonderen_email'];
			
			$site_adi = get_bloginfo('name');
			$konu = $site_adi .' E-Bülten Onayı';
			$gonderen = "$eposta_ayarlar_gonderen - <$eposta_ayarlar_email>";
			
			$icerik = '<body style="background-color:#D7D7D7;">
			<table width="600" style="margin-left: auto;margin-right: auto;background-color:#ffffff;" border="0" cellspacing="0" cellpadding="20">
			  <tbody>
				<tr style="background-color:#f5f5f5;">
				  <td>'.$site_adi.'</td>
				</tr>
				<tr><td><h1>E-Bülten Abonelik Onayınız</h1></td></tr>
				<tr>
				<td>	
					  <p>Abonelik işleminizi tamamlamak için aşağıdaki bağlantıya tıklamanız gerekmektedir.</p> 
					  <a href="'.$eposta_ayarlar_abonelik_onay_sayfasi.'?onay='.base64_encode( serialize($onaykodu)).'" style="background-color:#990000;color:#ffffff;padding:10px;text-decoration: none;margin-top:20px;display:inline-block;">E-Bülten Aboneliğimi Onayla</a>
				</td>	 
				</tr>

				<tr style="background-color:#f5f5f5;">
					  <td><small>'.$eposta_ayarlar_abonelik_bilgi_yazisi. '</small></td>		  
					</tr>
			  </tbody>
			</table>
			</body>';
			
			$headers = 'From: '. $gonderen . "\r\n" .
			'Content-Type: text/html; charset=UTF-8'. "\r\n".	
			'Reply-To: ' . $gonderen . "\r\n";
			
			wp_mail($abone_email_adresi,$konu,$icerik,$headers);

			$_SESSION['kullanici_uyarilari'] .= '<p>Aboneliğiniz yapılmıştır, girmiş olduğunuz email adresinizi kontrol ediniz.</p>';
		
		}
		
	}
	
	
	
	$uyari = '';
	$yonlendiren = $_SERVER['HTTP_REFERER'];
	wp_safe_redirect($yonlendiren);
	exit; 
	
}

add_action('admin_post_nopriv_listeye_abone_ekle','listeye_abone_ekle');
add_action('admin_post_listeye_abone_ekle','listeye_abone_ekle');