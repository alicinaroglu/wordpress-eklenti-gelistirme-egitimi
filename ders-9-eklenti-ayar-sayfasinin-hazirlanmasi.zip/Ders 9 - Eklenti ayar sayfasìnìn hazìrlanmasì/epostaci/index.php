<?php
/*
* Plugin Name: E-Postacı
* Plugin URI: https://www.alicinaroglu.com
* Description: Abone Listesi oluşturmanızı ve bu abonelere e-mail gönderimi yapmanızı sağlayan Wordpress eklentisidir.
* Version: 1.0.0
* Author: Ali Çınaroğlu
* Author URI: https://www.alicinaroglu.com
* Text Domain: epostaci
*/

//Admin Menüleri
function epostaci_admin_menuleri() {
	
add_menu_page( '', 'E-Postacı', 'manage_options', 'epostaci', 'epostaci', 'dashicons-email-alt' );
	
}
add_action('admin_menu', 'epostaci_admin_menuleri');

//Klasik Editör
add_filter('use_block_editor_for_post', '__return_false', 10);

//Dil Fonksiyonu  
function textdomain_func() {
  load_plugin_textdomain( 'epostaci', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}
add_action( 'init', 'textdomain_func' );


//Giriş Sayfası
include('sayfalar/epostaci.php');
