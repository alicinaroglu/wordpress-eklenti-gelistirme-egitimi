<?php function epostaci(){ ?>
	
<div class="wrap">
<h2>E-Postacı Eklenti Ayarları</h2>
<?php settings_errors(); ?> 
<?php $active_tab = isset( $_GET[ 'tab' ] ) ? $_GET[ 'tab' ] : 'eposta_genel_ayarlar_tab'; ?>  
<h2 class="nav-tab-wrapper">  
<a href="?page=epostaci&tab=eposta_genel_ayarlar_tab" class="nav-tab <?php echo $active_tab == 'eposta_genel_ayarlar_tab' ? 'nav-tab-active' : ''; ?>">E-Posta Gönderim Ayarları</a>  
<a href="?page=epostaci&tab=eposta_sayfalar_tab" class="nav-tab <?php echo $active_tab == 'eposta_sayfalar_tab' ? 'nav-tab-active' : ''; ?>">Sayfalar</a>  
</h2>  
<form action='options.php' method='post'>
<?php 
	if( $active_tab == 'eposta_genel_ayarlar_tab' ) {  
		settings_fields( 'epostaci_ayarlar' );
		do_settings_sections( 'epostaci_genel_ayarlar' ); 

	} else if( $active_tab == 'eposta_sayfalar_tab' ) {
		settings_fields( 'epostaci_sayfalar' );
		do_settings_sections( 'epostaci_sayfalar' ); 
	}
?> 
<?php submit_button(); ?>  
</form>
</div>

<?php	
}

function epostaci_ayarlari_goster() {

register_setting( 'epostaci_ayarlar', 'epostaci_ayarlar_secenekler' );
add_settings_section( 'epostaci_genel_ayarlar', '', '', 'epostaci_genel_ayarlar' );
	
add_settings_field( 'epostaci_eposta_gonderen_baslik', 'E-Posta Başlık', 'epostaci_eposta_gonderen_baslik_render', 'epostaci_genel_ayarlar', 'epostaci_genel_ayarlar' );
	

	
}

add_action("admin_init", "epostaci_ayarlari_goster");


function epostaci_eposta_gonderen_baslik_render() {
	
	echo "merhaba";
	
}

