<?php
function abonelik_formu_shortcode($args,$content=""){ 

session_destroy ();
if(isset($_SESSION['kullanici_uyarilari'])) {
   $uyari = $_SESSION['kullanici_uyarilari'];
} else {
   $uyari = '';
}
	

?>
<?php echo $uyari;?>	
<form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
	
<input type="email" name="email_adresi" id="email_adresi" placeholder="<?php _e( 'E-Mail Adresiniz', 'e-postaci' );?>" value="" required>
	
<?php wp_nonce_field( 'listeye_abone_ekle', 'listeye_abone_ekle_nonce' ); ?>
<input type="hidden" name="action" value="listeye_abone_ekle">
	
<input type="submit" name="" value="<?php _e( 'Abone Ol', 'e-postaci' );?>"/>	
</form>

<?php
}
add_shortcode('abonelik_formu', 'abonelik_formu_shortcode');

function listeye_abone_ekle() {
	
	global $post;
	
	$abone_email_adresi = $_POST['email_adresi'];
	
	$args = array(
	'numberposts'	=> -1,
	'post_type'		=> 'ebultenabonesi',
	'meta_key'		=> 'e-posta_adresi',
	'meta_value'	=> $abone_email_adresi,
	);

	$abone_kontrol = new WP_Query( $args );
	
	//echo "<pre>"; print_r($abone_kontrol); echo "</pre>";
	
	
	if($abone_kontrol->post_count > 0 ){
		
		$_SESSION['kullanici_uyarilari'] .= '<p>Bu e-posta adresi ile abonelik mevcut.</p>';	
		
	}
	
	else {
		
		$post_data = array(
		'post_title'    => $abone_email_adresi ,
		'post_type'     => 'ebultenabonesi',
		'post_status'   => 'publish'
		);
		$post_id = wp_insert_post( $post_data );
		update_post_meta( $post_id ,'e-posta_adresi', $abone_email_adresi);
		
		$_SESSION['kullanici_uyarilari'] .= '<p>Aboneliğiniz yapılmıştır, girmiş olduğunuz email adresinizi kontrol ediniz.</p>';
		
	}
	
	$uyari = '';
	$yonlendiren = $_SERVER['HTTP_REFERER'];
	wp_safe_redirect($yonlendiren);
	exit; 
	
}

add_action('admin_post_nopriv_listeye_abone_ekle','listeye_abone_ekle');
add_action('admin_post_listeye_abone_ekle','listeye_abone_ekle');