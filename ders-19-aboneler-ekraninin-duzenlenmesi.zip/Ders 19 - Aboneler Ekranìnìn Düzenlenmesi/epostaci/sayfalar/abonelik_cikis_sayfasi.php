<?php add_shortcode('abonelik_cikis_sayfasi','abonelik_cikis_sayfasi_shortcode');

function abonelik_cikis_sayfasi_shortcode($args,$content=""){
	
$gelenkod = unserialize(base64_decode($_GET['onay']));
	
$args = array(
'numberposts'	=> -1,
'post_type'		=> 'ebultenabonesi',
'meta_key'		=> 'onay_kodu',
'meta_value'	=> $gelenkod,
);

$abone_kontrol = new WP_Query( $args );	
	
if($gelenkod){
	
	if($abone_kontrol->post_count > 0 ) {
		
		$mevcut_kodu = get_post_meta($abone_kontrol->posts['0']->ID, 'onay_kodu', true);
	
		if($mevcut_kodu == $gelenkod){

			wp_delete_post($abone_kontrol->posts['0']->ID);
			
			echo "<p>E-Bülten aboneliğiniz sonlandırılmıştır.</p>";

		}

		else {

			echo "<p>Onay kodunuz hatalıdır veya bulunmamaktadır.</p>";

		}
		

	}
	
}	
	
else {
	
	echo "<p>Onay kodunuz bulunmamaktadır.</p>";
	
}
	
	
}