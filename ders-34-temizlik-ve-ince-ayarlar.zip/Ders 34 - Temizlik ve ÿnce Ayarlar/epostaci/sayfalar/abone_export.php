<?php function abone_export() {
?>
	<div class="wrap">
	<h2>Aboneleri Dışarı Aktar</h2>
	<p>Mevcut abonelerinizi csv formatında dışarı aktarabilirsiniz.</p>	
	<form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
	
	<button type="submit" class="button button-primary">İndir</button>	
	<?php wp_nonce_field( 'aboneleri_disari_aktar_func', 'aboneleri_disari_aktar_func_nonce' ); ?>
	<input type="hidden" name="action" value="aboneleri_disari_aktar_func">
	</form>
	</div>
<?php
}

function aboneleri_disari_aktar_func(){
	
	$abone_listesi_array = get_posts(array(
		'numberposts'	=> -1,
		'post_type'		=> 'ebultenabonesi',
		'meta_query'	=> array(
			'relation'		=> 'AND',
			array(
				'key'	 	=> 'e-posta_adresi',
			),
			array(
				'key'	  	=> 'onay_durumu',
				'value'	  	=> 'Evet',
				'compare' 	=> '=',
			),
		),
	));
	
	if($abone_listesi_array){
		
		$zaman = time();
		$zaman_format = date("d-m-y-h:i:s", $zaman);
		
		header('Content-type: application/csv');
		header('Content-Disposition: attachment; filename="abone-listesi-'.$zaman_format.'.csv"');
		header('Pragma: no-cache');
		header('Expires: 0');
		
		$file = fopen('php://output', 'w');
		
		fputcsv($file, array('Abone Adı', 'E-Mail Adresi'));
		
		foreach($abone_listesi_array as $abone_listesi_array_tek){
			
			$abone_adi = get_the_title( $abone_listesi_array_tek->ID);
			$abone_email = get_post_meta( $abone_listesi_array_tek->ID, 'e-posta_adresi', true);
			
			fputcsv($file, array($abone_adi, $abone_email));
			
		}
		
	}
	
	else {
		echo '<div class="notice notice-error is-dismissible"><p>Aktarılacak abone bulunmuyor.</p></div>';
		$yonlendiren = $_SERVER['HTTP_REFERER'];
		wp_safe_redirect($yonlendiren);
		exit;
	}
}

add_action('admin_post_nopriv_aboneleri_disari_aktar_func','aboneleri_disari_aktar_func');
add_action('admin_post_aboneleri_disari_aktar_func','aboneleri_disari_aktar_func');