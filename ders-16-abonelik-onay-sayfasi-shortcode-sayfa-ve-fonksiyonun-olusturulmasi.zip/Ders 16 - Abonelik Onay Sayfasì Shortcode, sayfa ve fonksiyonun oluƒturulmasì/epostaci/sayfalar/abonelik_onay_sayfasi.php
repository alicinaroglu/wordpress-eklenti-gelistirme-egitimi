<?php add_shortcode('abonelik_onay_sayfasi','abonelik_onay_sayfasi_shortcode');

function abonelik_onay_sayfasi_shortcode($args,$content=""){
	
$gelenkod = unserialize(base64_decode($_GET['onay']));
	
$args = array(
'numberposts'	=> -1,
'post_type'		=> 'ebultenabonesi',
'meta_key'		=> 'onay_kodu',
'meta_value'	=> $gelenkod,
);

$abone_kontrol = new WP_Query( $args );	
	
	
if($gelenkod){
	
	if($abone_kontrol->post_count > 0 ) {
		
	$mevcut_kodu = get_post_meta(get_the_ID(), 'onay_kodu', true);
	
	if($mevcut_kodu == $gelenkod){
		
		update_post_meta( get_the_ID() ,'onay_durumu', 'Evet');
		echo "<p>E-Posta Adresiniz Onaylandı</p>";
		
	}
	
	else {
		
		echo "<p>Onay kodunuz hatalıdır veya bulunmamaktadır.</p>";
		
	}
		

	}
	
}	
	
else {
	
	echo "<p>Onay kodunuz bulunmamaktadır.</p>";
	
}
	
	
}