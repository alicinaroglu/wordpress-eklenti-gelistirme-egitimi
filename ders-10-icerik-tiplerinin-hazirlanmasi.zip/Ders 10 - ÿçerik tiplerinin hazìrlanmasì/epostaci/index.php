<?php
/*
* Plugin Name: E-Postacı
* Plugin URI: https://www.alicinaroglu.com
* Description: Abone Listesi oluşturmanızı ve bu abonelere e-mail gönderimi yapmanızı sağlayan Wordpress eklentisidir.
* Version: 1.0.0
* Author: Ali Çınaroğlu
* Author URI: https://www.alicinaroglu.com
* Text Domain: epostaci
*/

//Admin Menüleri
function epostaci_admin_menuleri() {
	
add_menu_page( '', 'E-Postacı', 'manage_options', 'epostaci', 'epostaci', 'dashicons-email-alt' );
	
}
add_action('admin_menu', 'epostaci_admin_menuleri');

//Klasik Editör
add_filter('use_block_editor_for_post', '__return_false', 10);

//Dil Fonksiyonu  
function textdomain_func() {
  load_plugin_textdomain( 'epostaci', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}
add_action( 'init', 'textdomain_func' );


//Giriş Sayfası
include('sayfalar/epostaci.php');


//İçerik Tipi
function iceriktipleri() {

	$labels = array(
		'name'                => __( 'Aboneler' ),
		'singular_name'       => __( 'Aboneler' ),
		'menu_name'           => __( 'Aboneler' ),
		'parent_item_colon'   => __( 'Aboneler' ),
		'all_items'           => __( 'Tüm Aboneler' ),
		'view_item'           => __( 'Abone Gör' ),
		'add_new_item'        => __( 'Yeni Abone Ekle' ),
		'add_new'             => __( 'Yeni Abone Ekle' ),
		'edit_item'           => __( 'Abone Düzenle' ),
		'update_item'         => __( 'Abone Güncelle' ),
		'search_items'        => __( 'Abone Ara' ),
		'not_found'           => __( 'Bulunamadı' ),
		'not_found_in_trash'  => __( 'Çöpte Bulunamadı' ),
	);
	
	
	$args = array(
		'label'               => __( 'ebultenabonesi' ),
		'description'         => __( 'Aboneler' ),
		'labels'              => $labels,
		'supports'            => array( ''),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_rest' 		  => true,
		'rest_base'          => 'ebultenabonesi',
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 3,
		"menu_icon" => "dashicons-email-alt",   
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => true,
		'publicly_queryable'  => true,
		'capability_type'     => 'post',
	);
	
	register_post_type( 'ebultenabonesi', $args );
	
}

add_action( 'init', 'iceriktipleri', 0 );