<?php
/*
* Plugin Name: E-Postacı
* Plugin URI: https://www.alicinaroglu.com
* Description: Abone Listesi oluşturmanızı ve bu abonelere e-mail gönderimi yapmanızı sağlayan Wordpress eklentisidir.
* Version: 1.0.0
* Author: Ali Çınaroğlu
* Author URI: https://www.alicinaroglu.com
* Text Domain: epostaci
*/
