<?php
/*
* Plugin Name: E-Postacı
* Plugin URI: https://www.alicinaroglu.com
* Description: Abone Listesi oluşturmanızı ve bu abonelere e-mail gönderimi yapmanızı sağlayan Wordpress eklentisidir.
* Version: 1.0.0
* Author: Ali Çınaroğlu
* Author URI: https://www.alicinaroglu.com
* Text Domain: epostaci
*/

//Admin Menüleri
function epostaci_admin_menuleri() {
	
add_menu_page( '', 'E-Postacı', 'manage_options', 'epostaci', 'epostaci', 'dashicons-email-alt' );
add_submenu_page( 'epostaci', '', 'E-Mail Test', 'manage_options', 'email_test', 'email_test' );	
add_submenu_page( 'epostaci', '', 'Abone Listesi', 'manage_options', 'edit.php?post_type=ebultenabonesi' );	
}
add_action('admin_menu', 'epostaci_admin_menuleri');

//Klasik Editör
add_filter('use_block_editor_for_post', '__return_false', 10);

//Dil Fonksiyonu  
function textdomain_func() {
  load_plugin_textdomain( 'epostaci', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}
add_action( 'init', 'textdomain_func' );


//Giriş Sayfası
include('sayfalar/epostaci.php');
//Test Sayfası
include('sayfalar/email_test.php');
//Abonelik Sayfası
include('sayfalar/abonelik_formu.php');
//Abonelik Onay Sayfası
include('sayfalar/abonelik_onay_sayfasi.php');
//Abonelik Çıkış Sayfası
include('sayfalar/abonelik_cikis_sayfasi.php');
//Sessionlar

function register_session(){
    if( !session_id() )
        session_start();
}
add_action('init','register_session');

function admin_uyarilari(){
  if(!empty($_SESSION['admin_uyarilari'])) print $_SESSION['admin_uyarilari'];
  unset ($_SESSION['admin_uyarilari']);
}
add_action( 'admin_notices', 'admin_uyarilari' );


//İçerik Tipi
function iceriktipleri() {

	$labels = array(
		'name'                => __( 'Aboneler' ),
		'singular_name'       => __( 'Aboneler' ),
		'menu_name'           => __( 'Aboneler' ),
		'parent_item_colon'   => __( 'Aboneler' ),
		'all_items'           => __( 'Tüm Aboneler' ),
		'view_item'           => __( 'Abone Gör' ),
		'add_new_item'        => __( 'Yeni Abone Ekle' ),
		'add_new'             => __( 'Yeni Abone Ekle' ),
		'edit_item'           => __( 'Abone Düzenle' ),
		'update_item'         => __( 'Abone Güncelle' ),
		'search_items'        => __( 'Abone Ara' ),
		'not_found'           => __( 'Bulunamadı' ),
		'not_found_in_trash'  => __( 'Çöpte Bulunamadı' ),
	);
	
	
	$args = array(
		'label'               => __( 'ebultenabonesi' ),
		'description'         => __( 'Aboneler' ),
		'labels'              => $labels,
		'supports'            => array( ''),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => false,
		'show_in_rest' 		  => true,
		'rest_base'          => 'ebultenabonesi',
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 3,
		"menu_icon" => "dashicons-email-alt",   
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => true,
		'publicly_queryable'  => true,
		'capability_type'     => 'post',
	);
	
	register_post_type( 'ebultenabonesi', $args );
	
}

add_action( 'init', 'iceriktipleri', 0 );


//E-Mail Hata Fonksiyonu

function email_hata_ayiklama($wp_error){
	
	echo "<pre>"; print_r($wp_error); echo "</pre>";
	
}

add_action('wp_mail_failed','email_hata_ayiklama',10,1);

//PHP Mailer
function phpmailer_config(PHPMailer $mailer){
	
	$eposta_ayarlar = get_option( 'epostaci_ayarlar_secenekler' );
	
	$eposta_ayarlar_host = $eposta_ayarlar['gonderen_email_sunucu'];
	$eposta_ayarlar_kullanici_adi = $eposta_ayarlar['gonderen_email'];
	$eposta_ayarlar_sifre = $eposta_ayarlar['gonderen_email_sifre'];
	$eposta_ayarlar_baglanti_tipi = $eposta_ayarlar['gonderen_email_baglanti_tipi'];
	$eposta_ayarlar_port = $eposta_ayarlar['gonderen_email_port'];
	$eposta_ayarlar_baslik = $eposta_ayarlar['gonderen_baslik'];
	
	
	$mailer->IsSMTP();
	$mailer->Mailer = "smtp";
	$mailer->SMTPDebug  = 1;  
	$mailer->SMTPAuth   = TRUE;
	$mailer->SMTPSecure = $eposta_ayarlar_baglanti_tipi;
	$mailer->Port       = $eposta_ayarlar_port;
	$mailer->Host       = $eposta_ayarlar_host;
	$mailer->Username   = $eposta_ayarlar_kullanici_adi;
	$mailer->Password   = $eposta_ayarlar_sifre;
	$mailer->AddReplyTo($eposta_ayarlar_kullanici_adi, $eposta_ayarlar_baslik);
	$mailer->SetFrom($eposta_ayarlar_kullanici_adi, $eposta_ayarlar_baslik);
	$mailer->IsHTML(true);
	$mailer->Timeout = 10;
}
add_action( 'phpmailer_init', 'phpmailer_config', 10, 1);


//E-Bülten Widget
function ebulten_bileseni_yukle() {
    register_widget( 'ebulten_bileseni' );
}
add_action( 'widgets_init', 'ebulten_bileseni_yukle' );
 
class ebulten_bileseni extends WP_Widget {
 
function __construct() {
parent::__construct(
'ebulten_bileseni',__('E-Bülten Bileşeni'), 
array( 'description' => __( 'E-Bülten Abonelik Bileşeni' ) ) 
);
}
 
function widget( $args, $instance ) {
$bilesen_baslik = apply_filters( 'widget_title', $instance['title'] );
 
echo $args['before_widget'];
if ( ! empty( $bilesen_baslik ) )
echo $args['before_title'] . $bilesen_baslik . $args['after_title'];
?>

<?php echo do_shortcode('[abonelik_formu]');?>

<?php
echo $args['after_widget'];
}
       
function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$bilesen_baslik = $instance[ 'title' ];
}
else {
$bilesen_baslik = __( 'E-Bülten Bileşeni' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $bilesen_baslik ); ?>" />
</p>
<?php 
}
     
function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
return $instance;
}

}



//Abone Listesi Ekran Düzenlemeleri
add_filter( 'manage_ebultenabonesi_posts_columns', 'ozel_kolon_ekle' );
function ozel_kolon_ekle( $columns ) {
	$columns['emailadresi'] = 'E-Mail Adresi';
	$columns['onaydurumu'] = 'Onay Durumu';
    return $columns;
}


add_action( 'manage_ebultenabonesi_posts_custom_column' , 'ozel_kolon_ekle_data', 10, 2 );
function ozel_kolon_ekle_data( $column, $post_id ) {
    switch ( $column ) {
        case 'emailadresi' :
			echo get_post_meta($post_id,'e-posta_adresi', true);
            break;
		
		case 'onaydurumu' :
			echo get_post_meta($post_id,'onay_durumu', true);
            break;
    }
}

add_filter( 'manage_edit-ebultenabonesi_sortable_columns', 'ozel_kolon_ekle_siralanabilir_yap' );
function ozel_kolon_ekle_siralanabilir_yap( $columns ) {
	$columns['onaydurumu'] = 'onaydurumu';
	return $columns;
}

function ozel_kolon_ekle_siralanabilir_yap_data( $vars ) {

	if ( isset( $vars['post_type'] ) && 'ebultenabonesi' == $vars['post_type'] ) {

		if ( isset( $vars['orderby'] ) && 'onaydurumu' == $vars['orderby'] ) {

			$vars = array_merge(
				$vars,
				array(
					'meta_key' => 'onay_durumu',
					'orderby' => 'meta_value'
				)
			);
		}
		
	}

	return $vars;
}


//Toplu Düzenlemeler
add_filter( 'bulk_actions-edit-ebultenabonesi', 'toplu_duzenlemeler' );
function toplu_duzenlemeler($toplu_duzenlemeler) {
  $toplu_duzenlemeler['abone_onayla'] = __( 'Seçili Aboneleri Onayla', 'abone_onayla');
  $toplu_duzenlemeler['abone_onayini_kaldir'] = __( 'Seçili Abonelerin Onayını Kaldır', 'abone_onayini_kaldir');	
  return $toplu_duzenlemeler;
}

add_filter( 'handle_bulk_actions-edit-ebultenabonesi', 'toplu_duzenlemeler_actions', 10, 3 );
function toplu_duzenlemeler_actions( $redirect_to, $doaction, $post_ids ) {
	
if($doaction == "abone_onayla"){
	
  if ( $doaction !== 'abone_onayla' ) {
    return $redirect_to;
  }
	
  foreach ( $post_ids as $post_id ) {
	$onay_kodu = md5(time());  
    update_post_meta($post_id,'onay_durumu',"Evet");
	update_post_meta($post_id,'onay_kodu', $onay_kodu );
	update_post_meta($post_id,'gonderilenler',array());
  }
  $redirect_to = add_query_arg( 'aboneler_onaylandi', count( $post_ids ), $redirect_to );
  return $redirect_to;	
	
}	
	
else if($doaction == "abone_onayini_kaldir"){
	
  if ( $doaction !== 'abone_onayini_kaldir' ) {
    return $redirect_to;
  }
  foreach ( $post_ids as $post_id ) {
    update_post_meta($post_id,'onay_durumu',"Hayır");
	update_post_meta( $post_id, 'onay_kodu', "" );
  }
  $redirect_to = add_query_arg( 'abonelerin_onayi_kaldirildi', count( $post_ids ), $redirect_to );
  return $redirect_to;		
	
}
	
}


add_action( 'admin_notices', 'toplu_duzenlemeler_bilgi' );
function toplu_duzenlemeler_bilgi() {
	
  if ( ! empty( $_REQUEST['aboneler_onaylandi'] ) ) {
    $duzenlen_kisi_sayisi = intval( $_REQUEST['aboneler_onaylandi'] );
	echo '<div class="notice notice-success is-dismissible">
	<p>'.$duzenlen_kisi_sayisi.' abonenin hesabı onaylandı.</p>
	</div>';
  }
	
  else if ( ! empty( $_REQUEST['abonelerin_onayi_kaldirildi'] ) ) {
    $duzenlen_kisi_sayisi = intval( $_REQUEST['abonelerin_onayi_kaldirildi'] );
	echo '<div class="notice notice-success is-dismissible">
	<p>'.$duzenlen_kisi_sayisi.' abonenin onayı kaldırıldı.</p>
	</div>';
  }
	
}








