<?php function epostaci(){ 
	
	echo "merhaba dünya aaa";
	
}

