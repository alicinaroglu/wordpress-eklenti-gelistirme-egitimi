<?php
/*
* Plugin Name: E-Postacı
* Plugin URI: https://www.alicinaroglu.com
* Description: Abone Listesi oluşturmanızı ve bu abonelere e-mail gönderimi yapmanızı sağlayan Wordpress eklentisidir.
* Version: 1.0.0
* Author: Ali Çınaroğlu
* Author URI: https://www.alicinaroglu.com
* Text Domain: epostaci
*/

//Admin Menüleri
function epostaci_admin_menuleri() {
	
add_menu_page( '', 'E-Postacı', 'manage_options', 'epostaci', 'epostaci', 'dashicons-email-alt' );
add_submenu_page( 'epostaci', '', 'E-Mail Test', 'manage_options', 'email_test', 'email_test' );	
	
}
add_action('admin_menu', 'epostaci_admin_menuleri');

//Klasik Editör
add_filter('use_block_editor_for_post', '__return_false', 10);

//Dil Fonksiyonu  
function textdomain_func() {
  load_plugin_textdomain( 'epostaci', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}
add_action( 'init', 'textdomain_func' );


//Giriş Sayfası
include('sayfalar/epostaci.php');
//Test Sayfası
include('sayfalar/email_test.php');
//Abonelik Sayfası
include('sayfalar/abonelik_formu.php');


//Sessionlar

function register_session(){
    if( !session_id() )
        session_start();
}
add_action('init','register_session');

function admin_uyarilari(){
  if(!empty($_SESSION['admin_uyarilari'])) print $_SESSION['admin_uyarilari'];
  unset ($_SESSION['admin_uyarilari']);
}
add_action( 'admin_notices', 'admin_uyarilari' );


//İçerik Tipi
function iceriktipleri() {

	$labels = array(
		'name'                => __( 'Aboneler' ),
		'singular_name'       => __( 'Aboneler' ),
		'menu_name'           => __( 'Aboneler' ),
		'parent_item_colon'   => __( 'Aboneler' ),
		'all_items'           => __( 'Tüm Aboneler' ),
		'view_item'           => __( 'Abone Gör' ),
		'add_new_item'        => __( 'Yeni Abone Ekle' ),
		'add_new'             => __( 'Yeni Abone Ekle' ),
		'edit_item'           => __( 'Abone Düzenle' ),
		'update_item'         => __( 'Abone Güncelle' ),
		'search_items'        => __( 'Abone Ara' ),
		'not_found'           => __( 'Bulunamadı' ),
		'not_found_in_trash'  => __( 'Çöpte Bulunamadı' ),
	);
	
	
	$args = array(
		'label'               => __( 'ebultenabonesi' ),
		'description'         => __( 'Aboneler' ),
		'labels'              => $labels,
		'supports'            => array( ''),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_rest' 		  => true,
		'rest_base'          => 'ebultenabonesi',
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 3,
		"menu_icon" => "dashicons-email-alt",   
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => true,
		'publicly_queryable'  => true,
		'capability_type'     => 'post',
	);
	
	register_post_type( 'ebultenabonesi', $args );
	
}

add_action( 'init', 'iceriktipleri', 0 );


//E-Mail Hata Fonksiyonu

function email_hata_ayiklama($wp_error){
	
	echo "<pre>"; print_r($wp_error); echo "</pre>";
	
}

add_action('wp_mail_failed','email_hata_ayiklama',10,1);

//PHP Mailer
function phpmailer_config(PHPMailer $mailer){
	
	$eposta_ayarlar = get_option( 'epostaci_ayarlar_secenekler' );
	
	$eposta_ayarlar_host = $eposta_ayarlar['gonderen_email_sunucu'];
	$eposta_ayarlar_kullanici_adi = $eposta_ayarlar['gonderen_email'];
	$eposta_ayarlar_sifre = $eposta_ayarlar['gonderen_email_sifre'];
	$eposta_ayarlar_baglanti_tipi = $eposta_ayarlar['gonderen_email_baglanti_tipi'];
	$eposta_ayarlar_port = $eposta_ayarlar['gonderen_email_port'];
	$eposta_ayarlar_baslik = $eposta_ayarlar['gonderen_baslik'];
	
	
	$mailer->IsSMTP();
	$mailer->Mailer = "smtp";
	$mailer->SMTPDebug  = 1;  
	$mailer->SMTPAuth   = TRUE;
	$mailer->SMTPSecure = $eposta_ayarlar_baglanti_tipi;
	$mailer->Port       = $eposta_ayarlar_port;
	$mailer->Host       = $eposta_ayarlar_host;
	$mailer->Username   = $eposta_ayarlar_kullanici_adi;
	$mailer->Password   = $eposta_ayarlar_sifre;
	$mailer->AddReplyTo($eposta_ayarlar_kullanici_adi, $eposta_ayarlar_baslik);
	$mailer->SetFrom($eposta_ayarlar_kullanici_adi, $eposta_ayarlar_baslik);
	$mailer->IsHTML(true);
	$mailer->Timeout = 10;
}
add_action( 'phpmailer_init', 'phpmailer_config', 10, 1);


